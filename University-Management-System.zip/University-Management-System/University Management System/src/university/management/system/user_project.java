package university.management.system;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class user_project extends JFrame implements ActionListener{
    user_project(){
        super("SIBA Admission Management System");
        
        setSize(1920,1035);
        ImageIcon ic =  new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/siba.jpg"));
        Image i3 = ic.getImage().getScaledInstance(1990, 1030,Image.SCALE_DEFAULT);
        ImageIcon icc3 = new ImageIcon(i3);
        JLabel l1 = new JLabel(icc3);
        add(l1);  
        JMenuBar mb  = new JMenuBar();     
        JMenu attendance_detail = new JMenu("Attendance Detail");
         attendance_detail.setFont(new Font("monospaced",Font.BOLD,16));
        JMenuItem b1 = new JMenuItem("Student Attendance Detail");
     
        attendance_detail.setForeground(Color.DARK_GRAY);
        
        b1.setFont(new Font("monospaced",Font.BOLD,16));
//        ImageIcon icon27 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon15.png"));
      //  Image image28 = icon27.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
       // b1.setIcon(new ImageIcon(image28));
        b1.setMnemonic('O');
        b1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
        b1.setBackground(Color.WHITE);
        attendance_detail.add(b1);
        
        

        b1.addActionListener(this);
        
        JMenu fee = new JMenu("Fee Details");
        fee.setFont(new Font("monospaced",Font.BOLD,16));
        JMenuItem s1 = new JMenuItem("Fee Structure");
        JMenuItem s2 = new JMenuItem("Student Fee Form");
        fee.setForeground(Color.DARK_GRAY);
        
        s1.setFont(new Font("monospaced",Font.BOLD,16));
//        ImageIcon icon14 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon7.png"));
       // Image image15 = icon14.getImage().getScaledInstance(20, 20,Image.SCALE_DEFAULT);
       // s1.setIcon(new ImageIcon(image15));
        s1.setMnemonic('G');
        s1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.CTRL_MASK));
        s1.setBackground(Color.WHITE);
        
        s1.addActionListener(this);
        
        s2.setFont(new Font("monospaced",Font.BOLD,16));
//        ImageIcon icon16 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon8.png"));
        //Image image17 = icon16.getImage().getScaledInstance(20, 20,Image.SCALE_DEFAULT);
        //s2.setIcon(new ImageIcon(image17));
        s2.setMnemonic('H');
        s2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.CTRL_MASK));
        s2.setBackground(Color.WHITE);
        
        s2.addActionListener(this);
        

        JMenu utility = new JMenu("Utility");
        utility.setFont(new Font("monospaced",Font.BOLD,16));
        JMenuItem ut1 = new JMenuItem("Notepad");
        JMenuItem ut2 = new JMenuItem("Calculator");
        JMenuItem ut3 = new JMenuItem("Web Browser");
        utility.setForeground(Color.DARK_GRAY); 
        

        ut1.setFont(new Font("monospaced",Font.BOLD,16));
//        ImageIcon icon18 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon9.png"));
       // Image image19 = icon18.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        //ut1.setIcon(new ImageIcon(image19));
        ut1.setMnemonic('I');
        ut1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));
        ut1.setBackground(Color.WHITE);
        

        ut2.setFont(new Font("monospaced",Font.BOLD,16));
       // ImageIcon icon20 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon10.png"));
        //Image image21 = icon20.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        //ut2.setIcon(new ImageIcon(image21));
        ut2.setMnemonic('J');
        ut2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
        ut2.setBackground(Color.WHITE);
        

        ut3.setFont(new Font("monospaced",Font.BOLD,16));
       // ImageIcon icon10 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon11.png"));
        //Image image10 = icon10.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
       // ut3.setIcon(new ImageIcon(image10));
        ut3.setMnemonic('K');
        ut3.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W, ActionEvent.CTRL_MASK));
        ut3.setBackground(Color.WHITE);
        
        
        ut1.addActionListener(this);
        ut2.addActionListener(this);
        ut3.addActionListener(this);
        
        JMenu about = new JMenu("About");
        about.setFont(new Font("monospaced",Font.BOLD,16));
        JMenuItem aboutus = new JMenuItem("About Us");
        about.setForeground(Color.DARK_GRAY);
        
        aboutus.setFont(new Font("monospaced",Font.BOLD,16));
        //ImageIcon icon21 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon13.jpg"));
        //Image image22 = icon21.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
       // aboutus.setIcon(new ImageIcon(image22));
        aboutus.setMnemonic('L');
        aboutus.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));
        aboutus.setBackground(Color.WHITE);
        about.add(aboutus);
        aboutus.addActionListener(this);

        JMenu exit = new JMenu("Exit");
        exit.setFont(new Font("monospaced",Font.BOLD,16));
        JMenuItem ex = new JMenuItem("Exit");
        exit.setForeground(Color.DARK_GRAY);
        

        ex.setFont(new Font("monospaced",Font.BOLD,16));
        //ImageIcon icon11 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon12.png"));
        //Image image11 = icon11.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
       // ex.setIcon(new ImageIcon(image11));
        ex.setMnemonic('Z');
        ex.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, ActionEvent.CTRL_MASK));
        ex.setBackground(Color.WHITE);
        
        ex.addActionListener(this);
        
        

       
        
        fee.add(s1);
        fee.add(s2); 
        utility.add(ut1);
        utility.add(ut2);
        utility.add(ut3);     
        exit.add(ex);
        mb.add(attendance_detail);
        mb.add(fee);
        mb.add(utility);
        mb.add(about);
        mb.add(exit);
        setJMenuBar(mb);     
        setFont(new Font("Senserif",Font.BOLD,16));
        setLayout(new FlowLayout());
        setVisible(false);
    }
    public void actionPerformed(ActionEvent ae){
        String msg = ae.getActionCommand();
        if(msg.equals("New Student Admission")){
            new AddStudent().f.setVisible(true);
            
        }else if(msg.equals("New Faculty")){
            new AddTeacher().f.setVisible(true);
            
        }else if(msg.equals("Student Details")){
            new StudentDetails().setVisible(true);
            
        }else if(msg.equals("Teacher Details")){
            new TeacherDetails().setVisible(true);
           
        }
        else if(msg.equals("Update Students")){
            new UpdateStudent().f.setVisible(true);
           
        }
        else if(msg.equals("Update Teachers")){
            new UpdateTeacher().f.setVisible(true);
           
        }
        else if(msg.equals("Fee Structure")){
            new FeeStructure().setVisible(true);
           
        }
        else if(msg.equals("Student Fee Form")){
            new StudentFeeForm().setVisible(true);
           
        }
        else if(msg.equals("Notepad")){
            try{
                Runtime.getRuntime().exec("notepad.exe");
            }catch(Exception e){ }
        }else if(msg.equals("Calculator")){
            try{
                Runtime.getRuntime().exec("calc.exe");
            }catch(Exception e){ }
        }else if(msg.equals("Web Browser")){
            
            try{
                Runtime.getRuntime().exec("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
            }catch(Exception e){ }
        }else if(msg.equals("Exit")){
            System.exit(0);
        }else if(msg.equals("About Us")){
            new AboutUs().setVisible(true);
        }else if(msg.equals("Student Attendance")){
            new StudentAttendance().setVisible(true);
        }else if(msg.equals("Teacher Attendance")){
            new TeacherAttendance().setVisible(true);
        }else if(msg.equals("Student Attendance Detail")){
            new StudentAttendanceDetail().setVisible(true);
        }else if(msg.equals("Teacher Attendance Detail")){
            new TeacherAttendanceDetail().setVisible(true);
        }else if(msg.equals("Examination Details")){
            new ExaminationDetails().setVisible(true);
        }else if(msg.equals("Enter Marks")){
            new EnterMarks().setVisible(true);
        }
        
    }
    
    
    public static void main(String[] args){
        new user_project().setVisible(true);
    }
    
}
