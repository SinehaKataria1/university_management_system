package university.management.system;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Project extends JFrame implements ActionListener{
    Project(){
        super("SIBA Admission Management System");
        
        setSize(2000,1040);  
        ImageIcon ic =  new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/siba.jpg"));
        Image i3 = ic.getImage().getScaledInstance(1930, 1035,Image.SCALE_DEFAULT);
        ImageIcon icc3 = new ImageIcon(i3);
        JLabel l1 = new JLabel(icc3);
        
        add(l1);
        
        JMenuBar mb  = new JMenuBar();
        JMenu Admin = new JMenu("Admin");
        Admin .setFont(new Font("monospaced",Font.BOLD,16));
        JMenuItem Faculty = new JMenuItem("New Faculty");
        JMenuItem Student_Admission = new JMenuItem("New Student Admission");
        Admin.setForeground(Color.DARK_GRAY);
        
        
        Faculty.setFont(new Font("monospaced",Font.BOLD,16));
        ImageIcon icon1 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon1.png"));
        Image image1 = icon1.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        Faculty.setIcon(new ImageIcon(image1));
        Faculty.setMnemonic('A');
        Faculty.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, ActionEvent.CTRL_MASK));
        Faculty.setBackground(Color.WHITE);
        
        Student_Admission.setFont(new Font("monospaced",Font.BOLD,16));
        ImageIcon icon2 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon2.png"));
        Image image2 = icon2.getImage().getScaledInstance(20, 20,Image.SCALE_DEFAULT);
        Student_Admission.setIcon(new ImageIcon(image2));
        Student_Admission.setMnemonic('B');
        Student_Admission.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M, ActionEvent.CTRL_MASK));
        Student_Admission.setBackground(Color.WHITE);
    
        
        Faculty.addActionListener(this);
        Student_Admission.addActionListener(this);
        

  
        JMenu user = new JMenu("Show");
        user .setFont(new Font("monospaced",Font.BOLD,16));
        JMenuItem Student_Details  = new JMenuItem("Student Details");
        JMenuItem Teacher_Details = new JMenuItem("Teacher Details");
        user.setForeground(Color.DARK_GRAY);
        
        Student_Details.setFont(new Font("monospaced",Font.BOLD,16));
//        ImageIcon icon4 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon3.png"));
       // Image image4 = icon4.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        //Student_Details.setIcon(new ImageIcon(image4));
        Student_Details.setMnemonic('C');
        Student_Details.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
        Student_Details.setBackground(Color.WHITE);
        
        Teacher_Details.setFont(new Font("monospaced",Font.BOLD,16));
//        ImageIcon icon5 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon4.jpg"));
       // Image image5 = icon5.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        //Teacher_Details.setIcon(new ImageIcon(image5));
        Teacher_Details.setMnemonic('D');
        Teacher_Details.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B, ActionEvent.CTRL_MASK));
        Teacher_Details.setBackground(Color.WHITE);
        
        Student_Details.addActionListener(this);
        Teacher_Details.addActionListener(this);
        
        JMenu attendance = new JMenu("Attendance");
        attendance .setFont(new Font("monospaced",Font.BOLD,16));
        JMenuItem Student_Attendance = new JMenuItem("Student Attendance");
        JMenuItem Teacher_Attendance = new JMenuItem("Teacher Attendance");
        attendance.setForeground(Color.DARK_GRAY);
        
        Student_Attendance.setFont(new Font("monospaced",Font.BOLD,16));
//        ImageIcon icon23 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon14.jpg"));
        //Image image24 = icon23.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
       // Student_Attendance.setIcon(new ImageIcon(image24));
        Student_Attendance.setMnemonic('M');
        Student_Attendance.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
        Student_Attendance.setBackground(Color.WHITE);
        attendance.add(Student_Attendance);
        
        Teacher_Attendance.setFont(new Font("monospaced",Font.BOLD,16));
//        ImageIcon icon25 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon15.png"));
        //Image image26 = icon25.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        //Teacher_Attendance.setIcon(new ImageIcon(image26));
        Teacher_Attendance.setMnemonic('N');
        Teacher_Attendance.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B, ActionEvent.CTRL_MASK));
        Teacher_Attendance.setBackground(Color.WHITE);
        attendance.add(Teacher_Attendance);

        Student_Attendance.addActionListener(this);
        Teacher_Attendance.addActionListener(this);
        
        
        
        JMenu attendance_detail = new JMenu("Attendance Details");
        attendance_detail .setFont(new Font("monospaced",Font.BOLD,16));
        JMenuItem Student_Attendance_Detail = new JMenuItem("Student Attendance Detail");
        JMenuItem Teacher_Attendance_Detail = new JMenuItem("Teacher Attendance Detail");
        attendance_detail.setForeground(Color.DARK_GRAY);
        
        Student_Attendance_Detail.setFont(new Font("monospaced",Font.BOLD,16));
//        ImageIcon icon27 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon15.png"));
       // Image image28 = icon27.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
       // Student_Attendance_Detail.setIcon(new ImageIcon(image28));
        Student_Attendance_Detail.setMnemonic('O');
        Student_Attendance_Detail.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
        Student_Attendance_Detail.setBackground(Color.WHITE);
        attendance_detail.add(Student_Attendance_Detail);
        
        Teacher_Attendance_Detail.setFont(new Font("monospaced",Font.BOLD,16));
//        ImageIcon icon29 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon14.jpg"));
       // Image image30 = icon29.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        //Teacher_Attendance_Detail.setIcon(new ImageIcon(image30));
        Teacher_Attendance_Detail.setMnemonic('P');
        Teacher_Attendance_Detail.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B, ActionEvent.CTRL_MASK));
        Teacher_Attendance_Detail.setBackground(Color.WHITE);
        attendance_detail.add(Teacher_Attendance_Detail);

        Student_Attendance_Detail.addActionListener(this);
        Teacher_Attendance_Detail.addActionListener(this);
        
        
        JMenu exam = new JMenu("Examination");
        exam .setFont(new Font("monospaced",Font.BOLD,16));
        JMenuItem Examination_Details = new JMenuItem("Examination Details");
        JMenuItem Enter_Marks = new JMenuItem("Enter Marks");
        exam.setForeground(Color.DARK_GRAY);
        
        Examination_Details.setFont(new Font("monospaced",Font.BOLD,16));
        //ImageIcon icon30 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon16.png"));
        //Image image31 = icon30.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        //Examination_Details.setIcon(new ImageIcon(image31));
        Examination_Details.setMnemonic('Q');
        Examination_Details.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
        Examination_Details.setBackground(Color.WHITE);
        exam.add(Examination_Details);
        
        Enter_Marks.setFont(new Font("monospaced",Font.BOLD,16));
//        ImageIcon icon32 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon17.png"));
       // Image image33 = icon32.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
       // Enter_Marks.setIcon(new ImageIcon(image33));
        Enter_Marks.setMnemonic('R');
        Enter_Marks.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B, ActionEvent.CTRL_MASK));
        Enter_Marks.setBackground(Color.WHITE);
        exam.add(Enter_Marks);

        Examination_Details.addActionListener(this);
        Enter_Marks.addActionListener(this);
        
        JMenu report = new JMenu("Update Details");
        report .setFont(new Font("monospaced",Font.BOLD,16));
        JMenuItem Update_Students = new JMenuItem("Update Students");
        JMenuItem Update_Teachers = new JMenuItem("Update Teachers");
        report.setForeground(Color.DARK_GRAY);
        
        Update_Students.setFont(new Font("monospaced",Font.BOLD,16));
       // ImageIcon icon7 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon5.png"));
       // Image image7 = icon7.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        //Update_Students.setIcon(new ImageIcon(image7));
        Update_Students.setMnemonic('E');
        Update_Students.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.CTRL_MASK));
        Update_Students.setBackground(Color.WHITE);
        
        Update_Students.addActionListener(this);
        
        Update_Teachers.setFont(new Font("monospaced",Font.BOLD,16));
       // ImageIcon iconn = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon6.png"));
       // Image imagee = iconn.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
       // Update_Teachers.setIcon(new ImageIcon(imagee));
        Update_Teachers.setMnemonic('F');
        Update_Teachers.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.CTRL_MASK));
        Update_Teachers.setBackground(Color.WHITE);
        
        Update_Teachers.addActionListener(this);
     JMenu exit = new JMenu("Exit");
     exit .setFont(new Font("monospaced",Font.BOLD,16));
        JMenuItem ex = new JMenuItem("Exit");
        exit.setForeground(Color.DARK_GRAY);
        

        ex.setFont(new Font("monospaced",Font.BOLD,16));
       // ImageIcon icon11 = new ImageIcon(ClassLoader.getSystemResource("university/management/system/icons/icon12.png"));
       // Image image11 = icon11.getImage().getScaledInstance(25, 25,Image.SCALE_DEFAULT);
        //ex.setIcon(new ImageIcon(image11));
        ex.setMnemonic('Z');
        ex.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, ActionEvent.CTRL_MASK));
        ex.setBackground(Color.WHITE);
        
        ex.addActionListener(this);
        exit.add(ex);
        Admin.add(Faculty);
        Admin.add(Student_Admission);
        
        user.add(Student_Details);
        user.add(Teacher_Details);
        
        report.add(Update_Students);
        report.add(Update_Teachers);
        
        mb.add(Admin);
        mb.add(user);
        mb.add(attendance);
        mb.add(attendance_detail);
        mb.add(exam);
        mb.add(report);
        mb.add(exit);
        setJMenuBar(mb);    
        
        setFont(new Font("Senserif",Font.BOLD,16));
        setLayout(new FlowLayout());
        setVisible(false);
    }
    public void actionPerformed(ActionEvent ae){
        String msg = ae.getActionCommand();
        if(msg.equals("New Student Admission")){
            new AddStudent().f.setVisible(true);
            
        }else if(msg.equals("New Faculty")){
            new AddTeacher().f.setVisible(true);
            
        }else if(msg.equals("Student Details")){
            new StudentDetails().setVisible(true);
            
        }else if(msg.equals("Teacher Details")){
            new TeacherDetails().setVisible(true);
           
        }
        else if(msg.equals("Update Students")){
            new UpdateStudent().f.setVisible(true);
           
        }
        else if(msg.equals("Update Teachers")){
            new UpdateTeacher().f.setVisible(true);
           
        }
        else if(msg.equals("Fee Structure")){
            new FeeStructure().setVisible(true);
           
        }
        else if(msg.equals("Student Fee Form")){
            new StudentFeeForm().setVisible(true);
           
        }
        else if(msg.equals("Notepad")){
            try{
                Runtime.getRuntime().exec("notepad.exe");
            }catch(Exception e){ }
        }else if(msg.equals("Calculator")){
            try{
                Runtime.getRuntime().exec("calc.exe");
            }catch(Exception e){ }
        }else if(msg.equals("Web Browser")){
            
            try{
                Runtime.getRuntime().exec("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
            }catch(Exception e){ }
        }else if(msg.equals("Exit")){
            System.exit(0);
        }else if(msg.equals("About Us")){
            new AboutUs().setVisible(true);
        }else if(msg.equals("Student Attendance")){
            new StudentAttendance().setVisible(true);
        }else if(msg.equals("Teacher Attendance")){
            new TeacherAttendance().setVisible(true);
        }else if(msg.equals("Student Attendance Detail")){
            new StudentAttendanceDetail().setVisible(true);
        }else if(msg.equals("Teacher Attendance Detail")){
            new TeacherAttendanceDetail().setVisible(true);
        }else if(msg.equals("Examination Details")){
            new ExaminationDetails().setVisible(true);
        }else if(msg.equals("Enter Marks")){
            new EnterMarks().setVisible(true);
        }
        
    }
    
    
    public static void main(String[] args){
        new Project().setVisible(true);
    }
    
}
